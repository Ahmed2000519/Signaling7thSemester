package com.example.myapplication.Adapter

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.net.toUri
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.Models.InsertedDataTODataBase
import com.example.myapplication.R
import com.google.firebase.storage.FirebaseStorage
import java.io.File

class MyAdapter(private val productList : ArrayList<InsertedDataTODataBase>) : RecyclerView.Adapter<MyAdapter.MyViewHolder>() {

    private lateinit var mListener: onItemClickListener


    interface onItemClickListener{
        fun onItemClick(position: Int)
    }

    fun setOnItemClickListener(listener: onItemClickListener){
        mListener = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(
            R.layout.customer_item, parent, false)
        return MyViewHolder(itemView,mListener)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentitem= productList[position]
        holder.price.text = currentitem.price
        holder.ProductName.text = currentitem.productName
        holder.Quantity.text = currentitem.quantity
        val fn = currentitem.fileName.toString()
        val storageRef = FirebaseStorage.getInstance().reference.child("images/$fn")
        val localfile = File.createTempFile("tempImage","jpeg")

        storageRef.getFile(localfile).addOnSuccessListener {
            val bitmap = BitmapFactory.decodeFile(localfile.absolutePath)
            holder.image.setImageBitmap(bitmap)

        }.addOnFailureListener {

        }



    }

    override fun getItemCount(): Int {
        return productList.size
    }
    /*fun updateUserList(userList : List<InsertedDataTODataBase>){
        this.userList.clear()
        this.userList.addAll(userList)
        notifyDataSetChanged()
    }*/

    class MyViewHolder(itemView: View, listener: onItemClickListener): RecyclerView.ViewHolder(itemView){
        val ProductName: TextView = itemView.findViewById(R.id.tvProductName)
        val price: TextView = itemView.findViewById(R.id.tvPrice)
        val Quantity: TextView = itemView.findViewById(R.id.tvQuantity)
        val image : ImageView = itemView.findViewById(R.id.tvImage)

        init {
            itemView.setOnClickListener {
                listener.onItemClick(adapterPosition)
            }
        }

    }
}