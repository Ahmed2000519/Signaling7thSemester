package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

//Registration Activity
class MainActivity2 : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        auth = Firebase.auth
    }
    public override fun onStart() {
        super.onStart()

        val completeRegButton: Button = findViewById(R.id.CompleteRegButton)
        val signInPageButton: Button = findViewById(R.id.signInPageButton)


        //perform the sign-up process
        completeRegButton.setOnClickListener {
            val new_email = (findViewById<EditText>(R.id.RegEmailEntry)).text.toString()
            val new_pass = (findViewById<EditText>(R.id.RegPassEntry)).text.toString()
            auth.createUserWithEmailAndPassword(new_email,new_pass).addOnCompleteListener(this) { task ->
                 if (task.isSuccessful) {
                    // Sign in success, signInPageButton is enabled to be clicked
                    //val user = auth.currentUser
                    Toast.makeText(
                        baseContext, "Authentication success.",
                        Toast.LENGTH_SHORT
                    ).show()
                    signInPageButton.setOnClickListener {
                        val intentLogin = Intent(this,MainActivity::class.java)
                        startActivity(intentLogin)
                    }
                } else {
                    // If sign in fails, display a message to the user.
                    Toast.makeText(
                        baseContext, "Authentication failed.",
                        Toast.LENGTH_SHORT
                    ).show()

                }
            }



    }



    }
}