package com.example.myapplication.Models

import android.net.Uri

data class InsertedDataTODataBase(var productName: String?= null, var price: String?= null, var quantity: String?= null,var fileName:String?= null, var imageUri: String? = null)
