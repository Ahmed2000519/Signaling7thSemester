package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
//Login Activity
class MainActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        auth = Firebase.auth
    }
    public override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly.
        val signInButton = findViewById<Button>(R.id.buttonSignIn)
        val registerButton = findViewById<Button>(R.id.RegisterButton)
        val mapButton = findViewById<Button>(R.id.mapButton)
        val signOutButton = findViewById<Button>(R.id.dataButton)
        val customerBtn = findViewById<Button>(R.id.CustomerBtn)
        val vendorBtn = findViewById<Button>(R.id.VendorBtn)

        signInButton.setOnClickListener{
            val curr_email = (findViewById<EditText>(R.id.EmailEntry)).text.toString()
            val curr_pass = (findViewById<EditText>(R.id.PassEntry)).text.toString()
            auth.signInWithEmailAndPassword(curr_email, curr_pass)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        // Sign in success, update UI with the signed-in user's information
                        Toast.makeText(
                            baseContext, "Authentication success.",
                            Toast.LENGTH_SHORT
                        ).show()
                        val user = auth.currentUser

                        mapButton.setOnClickListener{

                        }
                        signOutButton.setOnClickListener{
                            auth.signOut()

                            if(Firebase.auth.currentUser == null){
                                Toast.makeText(baseContext, "User signed out successfully.",
                                    Toast.LENGTH_SHORT).show()
                            }
                            else{
                                Toast.makeText(baseContext, "Sign out failed.",
                                    Toast.LENGTH_SHORT).show()
                            }

                        }

                    } else {
                        // If sign in fails, display a message to the user.
                        Toast.makeText(baseContext, "Authentication failed.",
                            Toast.LENGTH_SHORT).show()
                    }
                }
        }


        registerButton.setOnClickListener {
            val intentReg = Intent(this,MainActivity2::class.java)
            startActivity(intentReg)
        }
        mapButton.setOnClickListener {
            val intentReg = Intent(this,MapsActivity::class.java)
            startActivity(intentReg)

        }
        customerBtn.setOnClickListener {
            val intentReg = Intent(this,CustomerActivity::class.java)
            startActivity(intentReg)

        }
        vendorBtn.setOnClickListener {
            val intentReg = Intent(this,ShopActivity::class.java)
            startActivity(intentReg)

        }




        }
    }
