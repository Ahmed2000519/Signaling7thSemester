package com.example.myapplication.VendorPart

import android.app.Activity.RESULT_OK
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.myapplication.Models.InsertedDataTODataBase
import com.example.myapplication.R
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import java.text.SimpleDateFormat
import java.util.*


class AddProductsFrag : Fragment() {
    lateinit var database: DatabaseReference
    companion object{

        var ImageUri :Uri = Uri.EMPTY
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_add_products, container, false)
        val btn = view.findViewById<FloatingActionButton>(R.id.floatingActionButton)
        val saveButton = view.findViewById<Button>(R.id.save)
        val selectImageBtn = view.findViewById<Button>(R.id.uploadPhoto)
        val image = view.findViewById<ImageView>(R.id.imageView)



        database = FirebaseDatabase.getInstance().getReference("Products")

        selectImageBtn.setOnClickListener {
            selectImage()
        }


        saveButton.setOnClickListener {
            val prodName = view.findViewById<EditText>(R.id.productName).text.toString()
            val prodPrice = view.findViewById<EditText>(R.id.price).text.toString()
            val prodQuantity = view.findViewById<EditText>(R.id.quantity).text.toString()

            var product : InsertedDataTODataBase

            val formatter = SimpleDateFormat("yyyy_MM_dd_HH_mm_ss", Locale.getDefault())
            val now = Date()
            val fileName = formatter.format(now)
            val storageReference = FirebaseStorage.getInstance().getReference("images/$fileName")


            storageReference.putFile(ImageUri).addOnSuccessListener {
                Toast.makeText(requireContext(),"Successfully uploaded",Toast.LENGTH_SHORT).show()

            }.addOnFailureListener {
                Toast.makeText(requireContext(),"Failed uploading",Toast.LENGTH_SHORT).show()

            }
            product = InsertedDataTODataBase(prodName, prodPrice, prodQuantity,fileName,ImageUri.toString())
            view.findViewById<ImageView>(R.id.imageView).setImageURI(null)
            database.child(prodName).setValue(product).addOnCompleteListener {
                //view.findViewById<EditText>(R.id.productName).text.clear()
                //view.findViewById<EditText>(R.id.price).text.clear()
                //view.findViewById<EditText>(R.id.quantity).text.clear()
                Toast.makeText(requireContext(), "Successfully Saved", Toast.LENGTH_SHORT).show()
            }.addOnFailureListener {
                Toast.makeText(requireContext(), "Failed", Toast.LENGTH_SHORT).show()
            }
        }

        btn.setOnClickListener {
            findNavController().navigate(R.id.action_addProductsFrag_to_editProductsFrag)
        }



        return view
    }

    private fun selectImage() {
        val intent = Intent()
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT
        startActivityForResult(intent,100)
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode == 100 && resultCode == RESULT_OK){
            ImageUri = data?.data!!
            view?.findViewById<ImageView>(R.id.imageView)?.setImageURI(ImageUri)


        }
    }
}




