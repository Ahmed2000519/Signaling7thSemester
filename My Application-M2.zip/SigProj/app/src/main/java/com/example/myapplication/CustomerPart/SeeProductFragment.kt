package com.example.myapplication.CustomerPart

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.Adapter.MyAdapter
import com.example.myapplication.Models.InsertedDataTODataBase
import com.example.myapplication.R
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.database.*

/*
private lateinit var viewModel : UserViewModel
private lateinit var userRecyclerView: RecyclerView
lateinit var adapter : MyAdapter
*/

class SeeProductFragment : Fragment() {
    lateinit var dbref :DatabaseReference
    lateinit var productRecyclerView: RecyclerView
    companion object{
        var cartArrayList = ArrayList<InsertedDataTODataBase>()
    }
    lateinit var productArrayList : ArrayList<InsertedDataTODataBase>


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view =  inflater.inflate(R.layout.fragment_see_product, container, false)
        val btn = view.findViewById<FloatingActionButton>(R.id.floatingActionButton3)
        productRecyclerView = view.findViewById(R.id.recycle1)
        productRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        productRecyclerView.setHasFixedSize(false)
        productArrayList = arrayListOf<InsertedDataTODataBase>()
        //cartArrayList = arrayListOf<InsertedDataTODataBase>()
        getProdData()



        btn.setOnClickListener {
            findNavController().navigate(R.id.action_seeProductFragment_to_yourCartFragment)
        }

        return view
    }
    fun getProdData(){
        dbref = FirebaseDatabase.getInstance().getReference("Products")
        dbref.addValueEventListener(object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                if(snapshot.exists()){
                    for (productSnapshot in snapshot.children){
                        val product = productSnapshot.getValue(InsertedDataTODataBase::class.java)
                        productArrayList.add(product!!)
                    }
                    var adapter = MyAdapter(productArrayList)
                    productRecyclerView.adapter = adapter
                    adapter.setOnItemClickListener(object : MyAdapter.onItemClickListener{
                        override fun onItemClick(position: Int) {
                            cartArrayList.add(productArrayList.get(position)!!)
                            Toast.makeText(requireContext(),"msg",Toast.LENGTH_SHORT).show()
                        }

                    })
                }


            }

            override fun onCancelled(error: DatabaseError) {

            }

        })
    }

/*
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        userRecyclerView = view.findViewById(R.id.recycle1)
        userRecyclerView.layoutManager = LinearLayoutManager(context)
        userRecyclerView.setHasFixedSize(true)
        adapter = MyAdapter()
        userRecyclerView.adapter = adapter

        viewModel = ViewModelProvider(this).get(UserViewModel::class.java)
        viewModel.allUser.observe(viewLifecycleOwner, Observer{
            adapter.updateUserList(it)
        })
    }*/

}