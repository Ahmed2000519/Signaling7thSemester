package com.example.myapplication.voip

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.myapplication.R

class MainVoIP : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_voip)

        findViewById<Button>(R.id.videoBtn).setOnClickListener {
            val intent = Intent(this, Video::class.java)
            startActivity(intent)
        }

        findViewById<Button>(R.id.voiceBtn).setOnClickListener {
            val intent = Intent(this, Voice::class.java)
            startActivity(intent)
        }
    }
}