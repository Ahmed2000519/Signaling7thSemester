package com.example.myapplication.VendorPart

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.myapplication.Models.InsertedDataTODataBase
import com.example.myapplication.R
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import java.text.SimpleDateFormat
import java.util.*


class DoEditFrag : Fragment() {
    var dbref : DatabaseReference = FirebaseDatabase.getInstance().getReference("Products")


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view =  inflater.inflate(R.layout.fragment_do_edit, container, false)
        val prodName = view.findViewById<TextView>(R.id.txtNameValue)
        val prodPrice = view.findViewById<TextView>(R.id.txtPriceValue)
        val prodQuantity = view.findViewById<TextView>(R.id.txtQuantityValue)
        val btnDelete = view.findViewById<Button>(R.id.btnDelete)
        val btnUpdate = view.findViewById<Button>(R.id.btnUpdate)
        val editName = (view.findViewById<EditText>(R.id.editName))
        val editPrice = (view.findViewById<EditText>(R.id.editPrice))
        val editQuantity = (view.findViewById<EditText>(R.id.editQuantity))
        prodName.text = EditProductsFrag.Companion.selectedProduct?.productName ?: String()
        prodPrice.text = EditProductsFrag.Companion.selectedProduct?.price ?: String()
        prodQuantity.text = EditProductsFrag.Companion.selectedProduct?.quantity ?: String()
        btnDelete.setOnClickListener {
            Toast.makeText(requireContext(),"msg", Toast.LENGTH_SHORT).show()
            dbref.child(EditProductsFrag.Companion.selectedProduct?.productName.toString()).removeValue()
            findNavController().navigate(R.id.action_doEditFrag_to_editProductsFrag)

        }



        btnUpdate.setOnClickListener {

            var name: String? = (EditProductsFrag.Companion.selectedProduct).productName
            var price: String? = (EditProductsFrag.Companion.selectedProduct).price
            var quantity: String? = (EditProductsFrag.Companion.selectedProduct).quantity
            val fileName : String? = (EditProductsFrag.Companion.selectedProduct).fileName
            val imageUri : String? = (EditProductsFrag.Companion.selectedProduct).imageUri


            if(editName.text.toString().equals("")){
                //name = (EditProductsFrag.Companion.selectedProduct).productName
            }
            else{
                name= editName.text.toString()
            }
            if(editPrice.text.toString().equals("")){
                //price = (EditProductsFrag.Companion.selectedProduct).price
                }
            else{
                price= editPrice.text.toString()
            }
            if(editQuantity.text.toString().equals("")){
                //quantity = (EditProductsFrag.Companion.selectedProduct).quantity
                }
            else{
                quantity= editQuantity.text.toString()
            }

            dbref.child(EditProductsFrag.Companion.selectedProduct?.productName.toString()).removeValue()

            dbref.child(name.toString()).setValue(InsertedDataTODataBase(name,price,quantity,fileName, imageUri))
            findNavController().navigate(R.id.action_doEditFrag_to_editProductsFrag)
        }

        return view
    }

}