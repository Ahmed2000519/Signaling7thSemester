package com.example.myapplication.Models

data class Loc(var shopID: String?= null, var latitude: String?= null, var longitude: String?= null)
