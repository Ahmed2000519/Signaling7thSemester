package com.example.myapplication.CustomerPart

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.Adapter.CartAdapter
import com.example.myapplication.R
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.maps.android.SphericalUtil
import kotlin.properties.Delegates


class YourCartFragment : Fragment() {
    lateinit var cartRecyclerView: RecyclerView
    var costSum by Delegates.notNull<Double>()
    //var cart:ArrayList<InsertedDataTODataBase> = SeeProductFragment().cartArrayList

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view =  inflater.inflate(R.layout.fragment_your_cart, container, false)
        val btn  = view.findViewById<FloatingActionButton>(R.id.floatingActionButton4)
        val txtView = view.findViewById<TextView>(R.id.total_cost)
        costSum = 0.0
        val distance : Double = SphericalUtil.computeDistanceBetween(MapsFragment.Companion.clientLocation,MapsFragment.Companion.selectedShop)/1000
        //Toast.makeText(requireContext(),distance.toString(), Toast.LENGTH_SHORT).show()
        costSum += (distance*10.0).toInt()

        cartRecyclerView = view.findViewById(R.id.recycle3)
        cartRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        cartRecyclerView.setHasFixedSize(false)
        for (i in SeeProductFragment.Companion.cartArrayList!!){
            costSum += (i.price!!).toInt()
        }
        txtView.text = costSum.toString()

        var adapter = CartAdapter(SeeProductFragment.Companion.cartArrayList!!)
        cartRecyclerView.adapter = adapter
        adapter.setOnItemClickListener(object : CartAdapter.onItemClickListener{
            override fun onItemClick(position: Int) {
                SeeProductFragment.Companion.cartArrayList.removeAt(position)
                for (i in SeeProductFragment.Companion.cartArrayList!!){
                    costSum += (i.price!!).toInt()
                }
                txtView.text = costSum.toString()
                findNavController().navigate(R.id.action_yourCartFragment_self)
            }

        })

        btn.setOnClickListener {
            findNavController().navigate(R.id.action_yourCartFragment_to_seeProductFragment)
        }
        return view
    }

}