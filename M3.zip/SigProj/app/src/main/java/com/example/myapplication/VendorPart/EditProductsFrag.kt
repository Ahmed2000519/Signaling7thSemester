package com.example.myapplication.VendorPart

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.Adapter.MyAdapter
import com.example.myapplication.Models.InsertedDataTODataBase
import com.example.myapplication.R
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.database.*


class EditProductsFrag : Fragment() {
    lateinit var dbref : DatabaseReference
    lateinit var productRecyclerView: RecyclerView
    lateinit var productArrayList : ArrayList<InsertedDataTODataBase>
    companion object{
        var selectedProduct : InsertedDataTODataBase = InsertedDataTODataBase()
        var selectedProdIndex : Int = 0

    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view =  inflater.inflate(R.layout.fragment_edit_products, container, false)
        val btn = view.findViewById<FloatingActionButton>(R.id.floatingActionButton2)
        productRecyclerView = view.findViewById(R.id.recycle2)
        productRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        productRecyclerView.setHasFixedSize(false)
        productArrayList = arrayListOf()
        getProdData()
        //Toast.makeText(requireContext(),productArrayList.size.toString(),Toast.LENGTH_SHORT).show()
        btn.setOnClickListener {
            findNavController().navigate(R.id.action_editProductsFrag_to_addProductsFrag)
        }

        return view
    }
    fun getProdData() {
        dbref = FirebaseDatabase.getInstance().getReference("Products")
        dbref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if(snapshot.exists()){
                    for (productSnapshot in snapshot.children){
                        val product = productSnapshot.getValue(InsertedDataTODataBase::class.java)
                        productArrayList.add(product!!)
                    }
                    Toast.makeText(requireContext(),productArrayList.size.toString(),Toast.LENGTH_SHORT).show()
                    var adapter = MyAdapter(productArrayList)
                    productRecyclerView.adapter = adapter
                    adapter.setOnItemClickListener(object : MyAdapter.onItemClickListener{
                        override fun onItemClick(position: Int) {
                            //cartArrayList.add(SeeProductFragment.productArrayList.get(position)!!)
                            EditProductsFrag.Companion.selectedProduct = productArrayList[position]
                            EditProductsFrag.Companion.selectedProdIndex = position
                            findNavController().navigate(R.id.action_editProductsFrag_to_doEditFrag)
                            Toast.makeText(requireContext(),"msg", Toast.LENGTH_SHORT).show()
                        }

                    })
                }


            }

            override fun onCancelled(error: DatabaseError) {

            }

        })

    }


}