package com.example.myapplication.VendorPart

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.myapplication.Models.Loc
import com.example.myapplication.R
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class AddLocation : Fragment() {
    lateinit var db : DatabaseReference
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.add_location, container, false)
        val submitBtn = view.findViewById<Button>(R.id.btnAddLocation)
        val longitude = view.findViewById<EditText>(R.id.txtLongitude)
        val latitude = view.findViewById<EditText>(R.id.txtLatitude)
        val id = view.findViewById<EditText>(R.id.txtID)
        val btn = view.findViewById<FloatingActionButton>(R.id.navFromLocationToAddProd)
        val idDelete = view.findViewById<EditText>(R.id.idDelete)
        val deleteBtn = view.findViewById<Button>(R.id.deleteBtn)

        submitBtn.setOnClickListener {
            val longitude = longitude.text.toString()
            val latitude = latitude.text.toString()
            val id = id.text.toString()
            val location = Loc(id,latitude,longitude)
            db = FirebaseDatabase.getInstance().getReference("Locations")
            db.child(id).setValue(location).addOnSuccessListener {
                Toast.makeText(requireContext(),"success in adding location",Toast.LENGTH_SHORT).show()
            }.addOnFailureListener{
                Toast.makeText(requireContext(),"failed to add location", Toast.LENGTH_SHORT).show()
            }

        }
        btn.setOnClickListener {
            findNavController().navigate(R.id.action_addLocation_to_addProductsFrag)
        }
        deleteBtn.setOnClickListener {
            val idDeleted = idDelete.text.toString()
            db.child(idDeleted).removeValue()

        }

        return view
    }
}